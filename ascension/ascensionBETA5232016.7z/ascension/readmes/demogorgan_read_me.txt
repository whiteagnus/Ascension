2001 - October - 21

*** These files are only intended for use for Baldur's Gate II with the Throne Of Bhaal expansion installed. They should not cause any conflicts or problems without it, but this cannot be guaranteed.

The files BEGUILE.SPL, DEMOCHM.SPL, DEMOGOR2.BCS, DEMOGOR2.CRE, POOLA10.EFF, SPIN548.SPL and SPIN549.SPL contained in this archive are the original pre-release versions of Baldur's Gate II: Throne Of Bhaal AI script, creature definition file and innate spells of Demogorgon.

They have been provided by BioWare Senior Designer David Gaider as a supplement to the Throne Of Bhaal expansion. They increase the difficulty of the Demogorgon battle, as it was originally planned before it was "toned down" for game balance reasons.

The update as of 2001-October-21 provided by Davadi Gaider resolves a couple of problems with both the original and released version of Demogorgon: his "beguiling gaze" was not working properly, and he wasn't dominating player-gated demons as he should.

To use:

Simply unzip the files DEMOGOR2.BCS, DEMOGOR2.CRE, SPIN548.SPL and SPIN549.SPL contained in this archive into the Override folder inside your Baldur's Gate II folder, and quit/restart Baldur's Gate II: Throne Of Bhaal (if it's already running.)

--------------------------
David Gaider's Disclaimer:
While provided by a Bioware employee, these files are not to be taken as part of the official release of Throne of Bhaal and should be considered equivalent to a third-party game addition or modification.  BioWare does not guarantee that these files will work with your copy of the game.  They are being provided solely due to requests for game enhancements, such as to experience certain game elements before they were removed or changed for game-balance or other reasons.
-------------------------

Kevin Dorner
mrkevvy@home.com
aka Kivan Do'Urner, solo CG E F/M/T
aaka Elmonster, solo LN H M

This file was obtained from my webpage at http://members.home.com/mrkevvy